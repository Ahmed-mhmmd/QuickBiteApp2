package com.example.quickbiteapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements MenuAdapter.OnItemClickListener {

    private RecyclerView recyclerView;
    private MenuAdapter adapter;
    private List<MenuItemModel> items;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerMenu);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        items = sampleMenu();
        adapter = new MenuAdapter(items, this);
        recyclerView.setAdapter(adapter);
    }

    private List<MenuItemModel> sampleMenu() {
        List<MenuItemModel> list = new ArrayList<>();
        list.add(new MenuItemModel("Burger", "Beef burger with cheese", 5.99));
        list.add(new MenuItemModel("Pizza Slice", "Cheesy pepperoni slice", 3.49));
        list.add(new MenuItemModel("Fries", "Crispy golden fries", 2.29));
        list.add(new MenuItemModel("Cola", "Chilled soft drink", 1.50));
        return list;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_cart) {
            startActivity(new Intent(this, CartActivity.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onItemClick(MenuItemModel item) {
        Intent i = new Intent(this, DetailsActivity.class);
        i.putExtra("name", item.getName());
        i.putExtra("desc", item.getDescription());
        i.putExtra("price", item.getPrice());
        startActivity(i);
    }
}
