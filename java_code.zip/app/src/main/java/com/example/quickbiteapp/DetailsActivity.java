package com.example.quickbiteapp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class DetailsActivity extends AppCompatActivity {

    private int qty = 1;
    private double price;
    private String name;
    private String desc;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        name = getIntent().getStringExtra("name");
        desc = getIntent().getStringExtra("desc");
        price = getIntent().getDoubleExtra("price", 0.0);

        TextView tvName = findViewById(R.id.tvName);
        TextView tvDesc = findViewById(R.id.tvDesc);
        TextView tvPrice = findViewById(R.id.tvPrice);
        TextView tvQty = findViewById(R.id.tvQty);
        Button btnPlus = findViewById(R.id.btnPlus);
        Button btnMinus = findViewById(R.id.btnMinus);
        Button btnAdd = findViewById(R.id.btnAddToCart);

        tvName.setText(name);
        tvDesc.setText(desc);
        tvPrice.setText(String.format("$%.2f", price));

        btnPlus.setOnClickListener(v -> {
            qty++;
            tvQty.setText(String.valueOf(qty));
        });

        btnMinus.setOnClickListener(v -> {
            if (qty > 1) qty--;
            tvQty.setText(String.valueOf(qty));
        });

        btnAdd.setOnClickListener(v -> {
            CartManager.getInstance().addItem(new CartItem(name, price, qty));
            Toast.makeText(this, "Added to cart", Toast.LENGTH_SHORT).show();
            finish();
        });
    }
}
