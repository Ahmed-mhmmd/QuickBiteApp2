package com.example.quickbiteapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class CartAdapter extends RecyclerView.Adapter<CartAdapter.Holder> {

    private final List<CartItem> data;

    public CartAdapter(List<CartItem> data) {
        this.data = data;
    }

    @NonNull
    @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_cart, parent, false);
        return new Holder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull Holder h, int position) {
        CartItem m = data.get(position);
        h.name.setText(m.getName());
        h.qty.setText("x" + m.getQuantity());
        h.price.setText(String.format("$%.2f", m.getSubtotal()));
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    static class Holder extends RecyclerView.ViewHolder {
        TextView name, qty, price;
        public Holder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.tvName);
            qty = itemView.findViewById(R.id.tvQty);
            price = itemView.findViewById(R.id.tvPrice);
        }
    }
}
