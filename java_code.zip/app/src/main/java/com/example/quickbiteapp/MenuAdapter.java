package com.example.quickbiteapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MenuAdapter extends RecyclerView.Adapter<MenuAdapter.Holder> {

    public interface OnItemClickListener {
        void onItemClick(MenuItemModel item);
    }

    private final List<MenuItemModel> data;
    private final OnItemClickListener listener;

    public MenuAdapter(List<MenuItemModel> data, OnItemClickListener listener) {
        this.data = data;
        this.listener = listener;
    }

    @NonNull
    @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_menu, parent, false);
        return new Holder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull Holder h, int position) {
        MenuItemModel m = data.get(position);
        h.name.setText(m.getName());
        h.desc.setText(m.getDescription());
        h.price.setText(String.format("$%.2f", m.getPrice()));
        h.itemView.setOnClickListener(v -> listener.onItemClick(m));
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    static class Holder extends RecyclerView.ViewHolder {
        TextView name, desc, price;
        public Holder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.tvName);
            desc = itemView.findViewById(R.id.tvDesc);
            price = itemView.findViewById(R.id.tvPrice);
        }
    }
}
